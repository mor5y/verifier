# Bulk email verifier

Syntax check -> MX lookup -> SMTP handshake (EHLO / MAIL FROM / RCPT TO, no message is sent).

## Install (Ubuntu VPS)

    sudo apt update && sudo apt install -y python3-venv
    cd email-verifier
    python3 -m venv venv && . venv/bin/activate
    pip install -r requirements.txt

## Run

    export HELO_HOST=your.vps.hostname      # should match the VPS reverse DNS (PTR)
    export MAIL_FROM=verify@yourdomain.com  # a real address on a domain you control
    export APP_PASSWORD='choose-a-password' # protects the web page (basic auth)
    gunicorn -w 1 --threads 8 --timeout 120 -b 0.0.0.0:8000 app:app

Open http://SERVER_IP:8000, upload a .txt, download `result_<name>.txt`
(valid addresses) and `report_<name>.txt` (email, status, reason per line).

Keep `-w 1`: job progress lives in memory.

## Run as a service (/etc/systemd/system/emailverifier.service)

    [Unit]
    Description=Email verifier
    After=network.target
    [Service]
    WorkingDirectory=/opt/email-verifier
    Environment=HELO_HOST=your.vps.hostname
    Environment=MAIL_FROM=verify@yourdomain.com
    Environment=APP_PASSWORD=choose-a-password
    ExecStart=/opt/email-verifier/venv/bin/gunicorn -w 1 --threads 8 --timeout 120 -b 0.0.0.0:8000 app:app
    Restart=always
    [Install]
    WantedBy=multi-user.target

    sudo systemctl daemon-reload && sudo systemctl enable --now emailverifier

## Statuses

- valid: server accepted RCPT TO
- invalid: 5xx rejection, or the domain has no mail server
- syntax: malformed address
- risky: domain accepts every address (catch-all), can't be confirmed
- unknown: timeout, greylisting, or the server blocked the probe

## Tuning (env vars)

WORKERS (30), PER_DOMAIN (3), SMTP_TIMEOUT (10), MAX_EMAILS (200000), MAX_UPLOAD_MB (20).

## Check outbound port 25 first

    timeout 8 bash -c '</dev/tcp/gmail-smtp-in.l.google.com/25' && echo open || echo blocked
