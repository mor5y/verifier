#!/usr/bin/env python3
"""
Bulk email verifier: syntax check + MX lookup + SMTP handshake (RCPT TO).
Upload a .txt file (one email per line), get result_<name>.txt back.

Run:  gunicorn -w 1 --threads 8 -b 0.0.0.0:8000 app:app
(one worker only: job state is kept in memory)
"""
import os
import re
import random
import smtplib
import string
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import dns.exception
import dns.resolver
from flask import Flask, Response, abort, jsonify, render_template_string, request, send_file
from werkzeug.utils import secure_filename

# ---------------------------------------------------------------- config
HELO_HOST = os.getenv("HELO_HOST", "mail.example.com")      # set to your VPS rDNS / hostname
MAIL_FROM = os.getenv("MAIL_FROM", "verify@example.com")    # envelope sender used for probes
WORKERS = int(os.getenv("WORKERS", "30"))                   # parallel checks
PER_DOMAIN = int(os.getenv("PER_DOMAIN", "3"))              # max simultaneous probes per domain
SMTP_TIMEOUT = float(os.getenv("SMTP_TIMEOUT", "10"))
MAX_EMAILS = int(os.getenv("MAX_EMAILS", "200000"))
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "20"))
APP_PASSWORD = os.getenv("APP_PASSWORD", "")                # if set, HTTP basic auth (any username)
JOB_DIR = Path(os.getenv("JOB_DIR", "jobs"))
JOB_TTL = 24 * 3600

JOB_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024

# ---------------------------------------------------------------- auth
@app.before_request
def _auth():
    if not APP_PASSWORD:
        return None
    a = request.authorization
    if a and a.password == APP_PASSWORD:
        return None
    return Response("Login required", 401, {"WWW-Authenticate": 'Basic realm="Email verifier"'})

# ---------------------------------------------------------------- verification
EMAIL_RE = re.compile(
    r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}"
    r"@(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}$"
)
BLOCK_HINTS = ("spamhaus", "blocked", "blacklist", "blocklist", "dnsbl", "rbl",
               "reputation", "access denied", "banned", "policy", "spam", "not authorized")

_mx_cache, _mx_lock = {}, threading.Lock()
_ca_cache, _ca_lock = {}, threading.Lock()
_gates, _gates_lock = {}, threading.Lock()


def syntax_ok(email: str) -> bool:
    if len(email) > 254 or not EMAIL_RE.match(email):
        return False
    local = email.rsplit("@", 1)[0]
    return not (local.startswith(".") or local.endswith(".") or ".." in local)


def get_mx(domain: str):
    """List of MX hosts, [] if the domain cannot receive mail, None on DNS failure."""
    with _mx_lock:
        if domain in _mx_cache:
            return _mx_cache[domain]
    res = dns.resolver.Resolver()
    res.lifetime = 8
    hosts = None
    try:
        ans = res.resolve(domain, "MX")
        recs = sorted(ans, key=lambda r: r.preference)
        hosts = [str(r.exchange).rstrip(".") for r in recs]
        if hosts == [""]:          # null MX (RFC 7505): domain accepts no mail
            hosts = []
    except dns.resolver.NoAnswer:
        try:
            res.resolve(domain, "A")
            hosts = [domain]       # implicit MX
        except dns.resolver.NoAnswer:
            hosts = []
        except dns.resolver.NXDOMAIN:
            hosts = []
        except dns.exception.DNSException:
            hosts = None
    except dns.resolver.NXDOMAIN:
        hosts = []
    except dns.exception.DNSException:
        hosts = None
    if hosts is not None:
        with _mx_lock:
            _mx_cache[domain] = hosts
    return hosts


def smtp_probe(hosts, rcpt):
    """Run EHLO / MAIL FROM / RCPT TO against the first reachable MX. Returns (code|None, message)."""
    last = (None, "no MX reachable")
    for host in hosts[:3]:
        try:
            with smtplib.SMTP(timeout=SMTP_TIMEOUT, local_hostname=HELO_HOST) as s:
                s.connect(host, 25)
                s.ehlo()
                code, msg = s.mail(MAIL_FROM)
                if code >= 400:
                    last = (code, msg.decode(errors="ignore"))
                    continue
                code, msg = s.rcpt(rcpt)
                return code, msg.decode(errors="ignore")
        except (smtplib.SMTPException, OSError) as e:
            last = (None, f"{type(e).__name__}: {e}"[:120])
    return last


def classify(code, msg):
    if code in (250, 251):
        return "valid", "mailbox accepted"
    if code is None:
        return "unknown", msg
    text = msg.lower()
    if code >= 500:
        if any(h in text for h in BLOCK_HINTS):
            return "unknown", f"{code} blocked by server policy"
        return "invalid", f"{code} mailbox rejected"
    return "unknown", f"{code} temporary / greylisted"


def is_catch_all(domain, hosts):
    with _ca_lock:
        if domain in _ca_cache:
            return _ca_cache[domain]
    rnd = "".join(random.choices(string.ascii_lowercase + string.digits, k=18))
    code, _ = smtp_probe(hosts, f"{rnd}@{domain}")
    result = True if code in (250, 251) else (False if code is not None and code >= 500 else None)
    with _ca_lock:
        _ca_cache[domain] = result
    return result


def gate(domain):
    with _gates_lock:
        if domain not in _gates:
            _gates[domain] = threading.Semaphore(PER_DOMAIN)
        return _gates[domain]


def verify(email):
    """Returns (status, reason). status: valid | invalid | syntax | risky | unknown"""
    if not syntax_ok(email):
        return "syntax", "bad syntax"
    domain = email.rsplit("@", 1)[1].lower()
    hosts = get_mx(domain)
    if hosts is None:
        return "unknown", "DNS lookup failed"
    if not hosts:
        return "invalid", "domain has no mail server"
    with gate(domain):
        if is_catch_all(domain, hosts) is True:
            return "risky", "domain accepts all addresses"
        code, msg = smtp_probe(hosts, email)
    return classify(code, msg)

# ---------------------------------------------------------------- jobs
JOBS, JOBS_LOCK = {}, threading.Lock()


def run_job(job):
    emails = job["emails"]
    results = [None] * len(emails)
    counts = job["counts"]

    def work(i):
        try:
            status, reason = verify(emails[i])
        except Exception as e:  # never let one address kill the job
            status, reason = "unknown", f"error: {type(e).__name__}"
        results[i] = (status, reason)
        with JOBS_LOCK:
            counts[status] += 1
            job["done"] += 1

    try:
        with ThreadPoolExecutor(max_workers=WORKERS) as ex:
            list(ex.map(work, range(len(emails))))

        keep = {"valid", "risky"} if job["include_risky"] else {"valid"}
        base = job["name"]
        out = JOB_DIR / job["id"]
        out.mkdir(exist_ok=True)
        (out / "result.txt").write_text(
            "\n".join(e for e, (s, _) in zip(emails, results) if s in keep) + "\n")
        (out / "report.txt").write_text(
            "\n".join(f"{e}\t{s}\t{r}" for e, (s, r) in zip(emails, results)) + "\n")
        job["result_name"] = f"result_{base}"
        job["report_name"] = f"report_{base}"
        job["finished"] = True
    except Exception as e:
        job["error"] = str(e)
        job["finished"] = True


def cleanup():
    now = time.time()
    with JOBS_LOCK:
        for jid in [j for j, v in JOBS.items() if now - v["created"] > JOB_TTL]:
            JOBS.pop(jid, None)
            d = JOB_DIR / jid
            if d.exists():
                for f in d.iterdir():
                    f.unlink(missing_ok=True)
                d.rmdir()


@app.post("/upload")
def upload():
    cleanup()
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify(error="Choose a .txt file first."), 400
    name = secure_filename(f.filename) or "emails.txt"
    if not name.lower().endswith(".txt"):
        return jsonify(error="Only .txt files are accepted."), 400
    raw = f.read().decode("utf-8", errors="ignore")
    seen, emails = set(), []
    for line in raw.splitlines():
        e = line.strip().strip(",;").lower()
        if e and e not in seen:
            seen.add(e)
            emails.append(e)
    if not emails:
        return jsonify(error="The file has no email addresses."), 400
    if len(emails) > MAX_EMAILS:
        return jsonify(error=f"Too many addresses ({len(emails)}). Limit is {MAX_EMAILS}."), 400
    job = {
        "id": uuid.uuid4().hex, "name": name, "emails": emails, "created": time.time(),
        "done": 0, "finished": False, "error": None,
        "include_risky": request.form.get("include_risky") == "1",
        "counts": {k: 0 for k in ("valid", "invalid", "syntax", "risky", "unknown")},
    }
    with JOBS_LOCK:
        JOBS[job["id"]] = job
    threading.Thread(target=run_job, args=(job,), daemon=True).start()
    return jsonify(id=job["id"], total=len(emails))


@app.get("/status/<jid>")
def status(jid):
    job = JOBS.get(jid) or abort(404)
    with JOBS_LOCK:
        return jsonify(total=len(job["emails"]), done=job["done"], counts=dict(job["counts"]),
                       finished=job["finished"], error=job["error"])


@app.get("/download/<jid>/<kind>")
def download(jid, kind):
    job = JOBS.get(jid) or abort(404)
    if not job["finished"] or kind not in ("result", "report"):
        abort(404)
    return send_file(JOB_DIR / jid / f"{kind}.txt", mimetype="text/plain",
                     as_attachment=True, download_name=job[f"{kind}_name"])

# ---------------------------------------------------------------- frontend
PAGE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Email list verifier</title>
<style>
:root{--bg:#f3f4f1;--ink:#1d2623;--mute:#5d6a65;--line:#cfd6d1;--acc:#0e6b5c;--acc-ink:#fff;--bad:#a63a2b;--card:#fbfbf9}
@media (prefers-color-scheme:dark){:root{--bg:#141a18;--ink:#e6ebe8;--mute:#8d9b95;--line:#2c3733;--acc:#3fb59f;--acc-ink:#0b1412;--bad:#e27a69;--card:#1a2220}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:640px;margin:0 auto;padding:48px 20px 64px}
h1{font-size:1.9rem;line-height:1.15;margin:0 0 8px;letter-spacing:-.02em}
p.lead{color:var(--mute);margin:0 0 28px;max-width:52ch}
#drop{display:block;border:2px dashed var(--line);border-radius:10px;padding:34px 20px;text-align:center;cursor:pointer;background:var(--card);transition:border-color .15s}
#drop:hover,#drop.over,#drop:focus-within{border-color:var(--acc)}
#drop input{position:absolute;opacity:0;width:1px;height:1px}
#fname{font-weight:600}
.opt{display:flex;gap:10px;align-items:flex-start;margin:18px 0;color:var(--mute);font-size:.95rem}
.opt input{margin-top:5px;accent-color:var(--acc)}
button,.btn{font:inherit;font-weight:600;border:0;border-radius:8px;padding:11px 20px;background:var(--acc);color:var(--acc-ink);cursor:pointer;text-decoration:none;display:inline-block}
button:disabled{opacity:.45;cursor:not-allowed}
button:focus-visible,.btn:focus-visible{outline:3px solid var(--ink);outline-offset:2px}
.btn.alt{background:transparent;color:var(--ink);border:1px solid var(--line)}
#run{display:none;margin-top:34px}
.bar{height:10px;background:var(--line);border-radius:6px;overflow:hidden}
.bar>i{display:block;height:100%;width:0;background:var(--acc);transition:width .4s}
#msg{margin:10px 0 18px;color:var(--mute)}
dl{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin:0 0 22px}
dl div{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:10px 12px}
dt{font-size:.8rem;color:var(--mute)}dd{margin:0;font-size:1.35rem;font-weight:700;font-variant-numeric:tabular-nums}
#err{color:var(--bad);margin-top:14px;min-height:1.4em}
#dl{display:none;gap:10px;flex-wrap:wrap}
@media(max-width:520px){dl{grid-template-columns:repeat(2,1fr)}}
</style></head><body><main>
<h1>Email list verifier</h1>
<p class="lead">Upload a .txt file with one address per line. Each address gets a syntax check, a mail-server lookup and an SMTP handshake. You download the addresses that passed.</p>
<label id="drop"><input type="file" id="file" accept=".txt,text/plain">
  <span id="fname">Choose a .txt file or drop it here</span></label>
<label class="opt"><input type="checkbox" id="risky">
  <span>Also keep addresses on accept-all domains. These servers say yes to every address, so the result can't be confirmed.</span></label>
<button id="go" disabled>Verify list</button>
<div id="err" role="alert"></div>
<section id="run" aria-live="polite">
  <div class="bar"><i id="fill"></i></div>
  <div id="msg"></div>
  <dl>
    <div><dt>Valid</dt><dd id="c-valid">0</dd></div>
    <div><dt>Invalid</dt><dd id="c-invalid">0</dd></div>
    <div><dt>Bad syntax</dt><dd id="c-syntax">0</dd></div>
    <div><dt>Accept-all</dt><dd id="c-risky">0</dd></div>
    <div><dt>Unknown</dt><dd id="c-unknown">0</dd></div>
  </dl>
  <div id="dl"><a class="btn" id="d-res" href="#">Download results</a>
    <a class="btn alt" id="d-rep" href="#">Download full report</a></div>
</section>
</main>
<script>
const $=id=>document.getElementById(id);
let file=null,timer=null;
function pick(f){file=f;$('fname').textContent=f?f.name:'Choose a .txt file or drop it here';$('go').disabled=!f}
$('file').onchange=e=>pick(e.target.files[0]);
const drop=$('drop');
['dragover','dragenter'].forEach(t=>drop.addEventListener(t,e=>{e.preventDefault();drop.classList.add('over')}));
['dragleave','drop'].forEach(t=>drop.addEventListener(t,e=>{e.preventDefault();drop.classList.remove('over')}));
drop.addEventListener('drop',e=>{if(e.dataTransfer.files[0])pick(e.dataTransfer.files[0])});
$('go').onclick=async()=>{
  $('err').textContent='';$('go').disabled=true;$('dl').style.display='none';
  const fd=new FormData();fd.append('file',file);fd.append('include_risky',$('risky').checked?'1':'0');
  let r,j;
  try{r=await fetch('upload',{method:'POST',body:fd});j=await r.json()}
  catch(e){$('err').textContent='Upload failed. Check your connection and try again.';$('go').disabled=false;return}
  if(!r.ok){$('err').textContent=j.error;$('go').disabled=false;return}
  $('run').style.display='block';poll(j.id);
};
function poll(id){
  clearInterval(timer);
  timer=setInterval(async()=>{
    const s=await (await fetch('status/'+id)).json();
    const pct=s.total?Math.round(s.done/s.total*100):0;
    $('fill').style.width=pct+'%';
    $('msg').textContent=s.finished?'Finished. '+s.total.toLocaleString()+' addresses checked.':'Checked '+s.done.toLocaleString()+' of '+s.total.toLocaleString()+' ('+pct+'%)';
    for(const k in s.counts)$('c-'+k).textContent=s.counts[k].toLocaleString();
    if(s.finished){clearInterval(timer);$('go').disabled=false;
      if(s.error){$('err').textContent='Job failed: '+s.error}
      else{$('d-res').href='download/'+id+'/result';$('d-rep').href='download/'+id+'/report';$('dl').style.display='flex'}}
  },1000);
}
</script></body></html>"""


@app.get("/")
def index():
    return render_template_string(PAGE)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, threaded=True)
